$(document).ready(function(){
    $(document.body).removeClass('preload')

    $('form input[type=text], form input[type=password]').first().focus()
})